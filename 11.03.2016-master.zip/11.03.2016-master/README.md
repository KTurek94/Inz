#**"Parówka"**
#Gra będzie polegać na znalezieniu pary w ukrytych obrazkach, celem gry jest odnalezienie wszystkich par w jak najmniejszej ilości ruchów. 

## Język: HTML / CSS / Javascript
 Wymagania: Sprawna przeglądarka ( Chrome)

### Plan
1.	Stworzenie szkieletu (ustalenie położenia oraz rozmiaru pola)
2.	Stworzenie przycisku odpowiadającego za rozpoczęcie ("START")
3.	Stworzenie pierwszych kafelków
4.	Stworzenie okna informującego o zakończeniu gry 
5.	Wprowadzenie wykrywania błędnego wyboru kafelków ( ponowne zakrycie)
6.	Stworzenie systemu odpowiadającego za odsłanianie kafelków (pokazanie obrazka) 
7.	Usuwanie z planszy dwóch takich samych kafelków
8.	Stworzenie systemu zliczającego próby
9.	Testy, poprawienie błędów oraz wyglądu aplikacji
